package com.adgvit.teambassador.ui.home;

public class TempTask
{
    String Task;
    String daysleft;
}
