package com.adgvit.teambassador.ui.home;

public class UserTask
{
    String HomeTutorialTitle;
    String HomeDaysLeft;
    int HomeColor;

    public UserTask(String homeTutorialTitle, String homeDaysLeft,int homeColor)
    {
        HomeTutorialTitle = homeTutorialTitle;
        HomeDaysLeft = homeDaysLeft;
        HomeColor=homeColor;
    }
}